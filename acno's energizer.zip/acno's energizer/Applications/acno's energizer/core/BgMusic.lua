bgmusic1 = Sound.load("Sound-Music/Music1.wav", true)
bgmusic2 = Sound.load("Sound-Music/Music2.wav", true)
bgmusic3 = Sound.load("Sound-Music/Music3.wav", true)

SoundSystem.SFXVolume(128) -- max 
SoundSystem.reverb(0) -- out of 15 
SoundSystem.panoramicSeparation(128) -- 0 is mono

function BgMusic1()
  voice = bgmusic1:play()
  voice:pan(128)
  voice:volume(255)
  voice:frequency(44100)
end

function BgMusic2()
  voice = bgmusic2:play()
  voice:pan(128)
  voice:volume(255)
  voice:frequency(44100)
end

function BgMusic3()
  voice = bgmusic3:play()
  voice:pan(128)
  voice:volume(255)
  voice:frequency(44100)
end

function BgMusic_Stop()
  if voice:playing() then
    voice:stop()
  end
end