dofile "core/Enemy AI/EnemyLeftRight.lua"
dofile "core/Enemy AI/EnemyUpDown.lua"
dofile "core/Enemy AI/EnemyMovement.lua"
slowdown=0

function enemy()
  if slowdown>=5 then
    enemyupdown()
    enemyleftright()
    slowdown=0
  else
    slowdown=slowdown+1
  end

  for by=1,18 do
    for bx=2,12 do
      if level[bx-1][by]==6 and level[bx][by]>=50 then
        level[bx][by]=2
        blowup(bx,by)
      end
    end
  end
end