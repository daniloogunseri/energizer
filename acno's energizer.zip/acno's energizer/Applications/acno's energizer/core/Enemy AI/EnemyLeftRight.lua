dir2=3

function enemyleftright()
  f5=0
  for y12=1,18 do
    for x12=1,12 do
      if level[x12][y12]==52 or level[x12][y12]==53 then
        if level[x12][y12-1]~=2 then
          dir2=3
        end
        if level[x12][y12+1]~=2 then
          dir2=4
        end
        if dir2==1 then
          enemyup(x12,y12)
          f5=1
          break
        elseif dir2==2 then
          enemydown(x12,y12)
          f5=1
          break
        elseif dir2==3 then
          enemyleft(x12,y12)
          f5=1
          break
        elseif dir2==4 then
          enemyright(x12,y12)
          f5=1
          break
        end
      end
    end
    if f5==1 then
      break
    end
  end
end
