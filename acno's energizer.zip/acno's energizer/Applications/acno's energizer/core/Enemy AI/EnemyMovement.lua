function enemyleft(x7,y7)
  temp=level[x7][y7]
  temp2=level[x7][y7-1]
  level[x7][y7]=temp2
  level[x7][y7-1]=temp
end
function enemydown(x8,y8)
  temp=level[x8][y8]
  temp2=level[x8+1][y8]
  level[x8][y8]=temp2
  level[x8+1][y8]=temp
end
function enemyright(x9,y9)
  temp=level[x9][y9]
  temp2=level[x9][y9+1]
  level[x9][y9]=temp2
  level[x9][y9+1]=temp
end
function enemyup(x10,y10)
  temp=level[x10][y10]
  temp2=level[x10-1][y10]
  level[x10][y10]=temp2
  level[x10-1][y10]=temp
end