dir=1

function enemyupdown()
  f4=0
  for y6=1,18 do
    for x6=1,12 do
      if level[x6][y6]==50 or level[x6][y6]==51 then
        if level[x6-1][y6]~=2 then
          level[x6][y6]=51
          dir=2
        end
        if level[x6+1][y6]~=2 then
          level[x6][y6]=50
          dir=1
        end
        if dir==1 then
          enemyup(x6,y6)
        elseif dir==2 then
          enemydown(x6,y6)
        elseif dir==3 then
          enemyleft(x6,y6)
        elseif dir==4 then
          enemyright(x6,y6)
        end
      end
    end
  end
end