function numballsleft()

status2:print(3,13,"Balls left: " .. totalb .. "/" .. nb,black)

end