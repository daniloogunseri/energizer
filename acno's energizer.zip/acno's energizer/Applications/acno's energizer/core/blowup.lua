function blowup(x11,y11)
  if level[x11-1][y11-1] == 7 or level[x11-1][y11-1] == 6 then
    level[x11-1][y11-1] = 2
  end
  if level[x11+1][y11+1] == 7 or level[x11+1][y11+1] == 6 then
    level[x11+1][y11+1] = 2
  end
  if level[x11-1][y11] == 7 or level[x11-1][y11] == 6 then
    level[x11-1][y11] = 2
  end
  if level[x11+1][y11] == 7 or level[x11+1][y11] == 6 then
    level[x11+1][y11] = 2
  end
  if level[x11][y11-1] == 7 or level[x11][y11-1] == 6 then
    level[x11][y11-1] = 2
  end
  if level[x11][y11+1] == 7 or level[x11][y11+1] == 6 then
    level[x11][y11+1] = 2
  end
  if level[x11-1][y11+1] == 7 or level[x11-1][y11+1] == 6 then
    level[x11-1][y11+1] = 2
  end
  if level[x11+1][y11-1] == 7 or level[x11+1][y11-1] == 6 then
    level[x11+1][y11-1] = 2
  end
end