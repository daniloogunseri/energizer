function cingamemenu(clvlnum)
  local ingameitem=1
  local menuback_=false
  tl:reset()
  while not menuback_ do
    screen:clear()
    display()
    status()
    screen:fillRect(screen:width()/2-86, screen:height()/2-24, 67, 30, gray)
    screen:print(screen:width()/2-75, screen:height()/2-23, "Save", green)
    screen:print(screen:width()/2-75, screen:height()/2-13, "Restart", green)
    screen:print(screen:width()/2-75, screen:height()/2-3, "Quit", green)
    
    if ingameitem==1 then
      screen:print(screen:width()/2-83, screen:height()/2-23, ">Save", white)
    elseif ingameitem==2 then
      screen:print(screen:width()/2-83, screen:height()/2-13, ">Restart", white)
    elseif ingameitem==3 then
      screen:print(screen:width()/2-83, screen:height()/2-3, ">Quit", white)
    end
    
    screen:waitVblankStart()
    screen.flip()

    if up1() then
      ingameitem=ingameitem-1
      if ingameitem==0 then
        ingameitem=3
      end
    elseif down1() then
      ingameitem=ingameitem+1
      if ingameitem==4 then
        ingameitem=1
      end
    end

    if cross1() or circle1() then
      if ingameitem==1 then
      elseif ingameitem==2 then
        clvl(clvlnum)
        tl:reset()
        tl:start()
        menuback_=true
      elseif ingameitem==3 then
        exit_=true
        gameover_=true
        menuback_=true
        tl:stop()
        BgMusic_Stop()
        BgMusic1()
      end
    end

    if square1() or triangle1() then
      menuback_=true
      tl:reset()
      tl:start()
    end
  end
  creset()
end