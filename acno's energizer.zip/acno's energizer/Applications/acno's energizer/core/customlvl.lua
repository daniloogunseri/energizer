clvl()
while not exit_ do
  if nlvl == true then
  lvl = lvl+1
  break
  end
  screen:clear(black)
  if not gameover_ then
    display()
    move()
    fall()
    if ene then
      enemy()
    end
  end
  time()
  status()
  screen:waitVblankStart()
  screen.flip()
  if start() then
    ingamemenu(clvlnum)
  end
  if gameover_ then
    exit_=true
  end
end
creset()