function display()
  a = 0
  b = 0

  for y = 1,18 do
    for x = 1,12 do
    if level[x][y] == 0 then
--      c = "-"
      d = wall
    end
    if level[x][y] == 4 then
--      c = "P"
      d = player
    end
    if level[x][y] == 2 then
--      c = " "
      d = blank
    end
    if level[x][y] == 5 then
--      c = "o"
      d = ball1
    end
    if level[x][y] == 3 then
--      c = "~"
      d = exit2
    end
    if level[x][y] == 1 then
--      c = "#"
      d = dirt
    end
    if level[x][y] == 9 then
--      c = "E"
      d = exit
    end
    if level[x][y] == 6 then
--      c = "R"
      d = rocka
    end
    if level[x][y] == 7 then
--      c = "W2"
      d = wall2
    end
    if level[x][y] == 50 then
--      c = "E1"
      d = enemy1u
    end
    if level[x][y] == 51 then
--      c = "E2"
      d = enemy1d
    end
    if level[x][y] == 52 then
--      c = "E3"
      d = enemy1l
    end
    if level[x][y] == 53 then
--      c = "E4"
      d = enemy1r
    end
    screen:blit(a,b,d)
--    screen:print(a, b, c, black)
    b = b+20
    end
    a = a+20
    b = 0
  end
end