totalb = 0

function fall()
  f2 = 0
  f3 = 0
  for y2 = 1,18 do
    for x2 = 1,12 do
      if level[x2][y2] == 5 then
        if level[x2+1][y2] == 3 then
          level[x2][y2] = 2
          totalb = totalb+1
          if totalb == nb then
            level[x2+1][y2] = 9
          end
        end
        if level[x2+1][y2] == 2 then
          ball(x2,y2)
          f2 = 1
          break
        end
      end
    end
    if f2 == 1 then
      break
    end
  end

  for y3 = 1,18 do
    for x3 = 1,12 do
      if level[x3][y3] == 6 then
        if level[x3+1][y3] == 2 then
          rock(x3,y3)
          f3 = 1
          break
        end
      end
    end
    if f3 == 1 then
      break
    end
  end
end

function ball(x4,y4)
  temp = level[x4][y4]
  temp2 = level[x4+1][y4]
  level[x4][y4] = temp2
  level[x4+1][y4] = temp
end

function rock(x5,y5)
  temp = level[x5][y5]
  temp2 = level[x5+1][y5]
  level[x5][y5] = temp2
  level[x5+1][y5] = temp
end