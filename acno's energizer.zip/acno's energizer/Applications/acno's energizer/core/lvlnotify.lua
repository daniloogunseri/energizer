function lvlnotify(lvl)
  while not buttons() do
    screen:clear()
    display()
    status()
    screen:fillRect(screen:width()/2-86, screen:height()/2-24, 83, 20, gray)
    screen:print(screen:width()/2-83, screen:height()/2-23, "Next Level", green)
    screen:print(screen:width()/2-83, screen:height()/2-13, "Level: " .. lvl, green)
    screen:waitVblankStart()
    screen.flip()
  end
  creset()
end