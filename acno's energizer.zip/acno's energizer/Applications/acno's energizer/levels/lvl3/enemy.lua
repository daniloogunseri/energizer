dir=1

function enemy()
  f4=0
  for y6=1,18 do
    for x6=1,12 do
      if level[x6][y6]==50 or level[x6][y6]==51 or level[x6][y6]==52 or level[x6][y6]==53 then
        if level[x6-1][y6]~=2 then
          dir=2
        end
        if level[x6+1][y6]~=2 then
          dir=1
        end
        if level[x6-1][y6]==6 then
          dir=0
          level[x6][y6]=2
          blowup(x6,y6)
        end
        if dir==1 then
          enemyup(x6,y6)
          f4=1
          break
        elseif dir==2 then
          enemydown(x6,y6)
          f4=1
          break
        elseif dir==3 then
          enemyleft(x6,y6)
          f4=1
          break
        elseif dir==4 then
          enemyright(x6,y6)
          f4=1
          break
        end
      end
    end
    if f4==1 then
      break
    end
  end
end

function enemyleft(x7,y7)
  temp=level[x7][y7]
  temp2=level[x7][y7-1]
  level[x7][y7]=temp2
  level[x7][y7-1]=temp
end
function enemydown(x8,y8)
  temp=level[x8][y8]
  temp2=level[x8+1][y8]
  level[x8][y8]=temp2
  level[x8+1][y8]=temp
end
function enemyright(x9,y9)
  temp=level[x9][y9]
  temp2=level[x9][y9+1]
  level[x9][y9]=temp2
  level[x9][y9+1]=temp
end
function enemyup(x10,y10)
  temp=level[x10][y10]
  temp2=level[x10-1][y10]
  level[x10][y10]=temp2
  level[x10-1][y10]=temp
end