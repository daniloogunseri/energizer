System.currentDirectory("Applications")
appsDir = System.currentDirectory()

System.currentDirectory("acno's energizer")
dofile("index.lua")